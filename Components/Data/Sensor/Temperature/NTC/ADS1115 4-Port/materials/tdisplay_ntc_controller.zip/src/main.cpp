#include <Arduino.h>
#include <Wire.h>
#include <TFT_eSPI.h>
#include <lvgl.h>
#include <math.h>

#include "config.h"

// -----------------------------------------------------------------------------
// Hardware
// -----------------------------------------------------------------------------

TFT_eSPI tft;

static lv_disp_draw_buf_t drawBuffer;
static lv_color_t drawPixels[Config::SCREEN_W * 20];

// -----------------------------------------------------------------------------
// ADS1115 register-level driver
// -----------------------------------------------------------------------------

namespace ADS1115 {

constexpr uint8_t REG_CONVERSION = 0x00;
constexpr uint8_t REG_CONFIG     = 0x01;

// PGA = +/-4.096 V -> 125 uV/LSB.
constexpr float LSB_VOLTS = 0.000125f;

// ADS1115 config bits used here:
// OS=1            start single conversion
// MUX=100..111    AIN0..AIN3 single-ended
// PGA=001         +/-4.096 V
// MODE=1          single-shot
// DR=000          8 samples/s (maximum internal oversampling/filtering)
// COMP_QUE=11     comparator disabled
constexpr uint16_t CONFIG_BASE =
    (1u << 15) |      // OS
    (1u << 9)  |      // PGA = +/-4.096 V
    (1u << 8)  |      // single-shot mode
    0x0003u;          // comparator disabled

bool writeRegister(uint8_t reg, uint16_t value) {
    Wire.beginTransmission(Config::ADS1115_ADDRESS);
    Wire.write(reg);
    Wire.write(static_cast<uint8_t>(value >> 8));
    Wire.write(static_cast<uint8_t>(value & 0xFF));
    return Wire.endTransmission() == 0;
}

bool readRegister(uint8_t reg, uint16_t &value) {
    Wire.beginTransmission(Config::ADS1115_ADDRESS);
    Wire.write(reg);
    if (Wire.endTransmission(false) != 0) {
        return false;
    }

    if (Wire.requestFrom(static_cast<int>(Config::ADS1115_ADDRESS), 2) != 2) {
        return false;
    }

    value = (static_cast<uint16_t>(Wire.read()) << 8) |
            static_cast<uint16_t>(Wire.read());
    return true;
}

bool probe() {
    Wire.beginTransmission(Config::ADS1115_ADDRESS);
    return Wire.endTransmission() == 0;
}

bool startSingleEnded(uint8_t channel) {
    if (channel > 3) return false;
    const uint16_t mux = static_cast<uint16_t>(0x04u + channel) << 12;
    return writeRegister(REG_CONFIG, CONFIG_BASE | mux);
}

bool conversionReady(bool &ready) {
    uint16_t cfg = 0;
    if (!readRegister(REG_CONFIG, cfg)) return false;
    ready = (cfg & 0x8000u) != 0;
    return true;
}

bool readConversion(int16_t &raw) {
    uint16_t value = 0;
    if (!readRegister(REG_CONVERSION, value)) return false;
    raw = static_cast<int16_t>(value);
    return true;
}

} // namespace ADS1115

// -----------------------------------------------------------------------------
// Temperature model
// -----------------------------------------------------------------------------

enum class ProbeState : uint8_t {
    Unknown,
    Valid,
    Open,
    Short,
    AdcError
};

struct ProbeReading {
    int16_t raw = 0;
    float voltage = NAN;
    float resistance = NAN;
    float temperature = NAN;
    float filteredTemperature = NAN;
    ProbeState state = ProbeState::Unknown;
};

static ProbeReading probes[4];

static void calculateProbe(uint8_t channel, int16_t raw) {
    ProbeReading &p = probes[channel];
    p.raw = raw;

    if (raw < 0) {
        p.state = ProbeState::AdcError;
        return;
    }

    p.voltage = static_cast<float>(raw) * ADS1115::LSB_VOLTS;

    // Fault detection leaves plenty of margin for the useful B3435 temperature range.
    if (p.voltage < Config::DIVIDER_VCC * 0.015f) {
        p.state = ProbeState::Short;
        return;
    }
    if (p.voltage > Config::DIVIDER_VCC * 0.985f) {
        p.state = ProbeState::Open;
        return;
    }

    const float denominator = Config::DIVIDER_VCC - p.voltage;
    if (denominator <= 0.0f) {
        p.state = ProbeState::Open;
        return;
    }

    // Fixed resistor -> VCC, NTC -> GND:
    // Vout = VCC * Rntc / (Rfixed + Rntc)
    p.resistance = Config::FIXED_R_OHM[channel] * p.voltage / denominator;

    if (!isfinite(p.resistance) || p.resistance <= 0.0f) {
        p.state = ProbeState::AdcError;
        return;
    }

    const float invT =
        (1.0f / Config::NTC_T0_K) +
        (logf(p.resistance / Config::NTC_R25_OHM) / Config::NTC_BETA_K);

    p.temperature = (1.0f / invT) - 273.15f;

    if (!isfinite(p.temperature)) {
        p.state = ProbeState::AdcError;
        return;
    }

    if (!isfinite(p.filteredTemperature)) {
        p.filteredTemperature = p.temperature;
    } else {
        p.filteredTemperature +=
            Config::EMA_ALPHA * (p.temperature - p.filteredTemperature);
    }

    p.state = ProbeState::Valid;
}

// -----------------------------------------------------------------------------
// LVGL display
// -----------------------------------------------------------------------------

static lv_obj_t *tempLabels[4] = {nullptr, nullptr, nullptr, nullptr};
static lv_obj_t *statusLabel = nullptr;
static lv_obj_t *statusDot = nullptr;

static const uint32_t accentColors[4] = {
    0x35D0BA,
    0x5EA2FF,
    0xFFB547,
    0xC77DFF
};

static void displayFlush(lv_disp_drv_t *disp,
                         const lv_area_t *area,
                         lv_color_t *colorP) {
    const uint32_t width = area->x2 - area->x1 + 1;
    const uint32_t height = area->y2 - area->y1 + 1;

    tft.startWrite();
    tft.setAddrWindow(area->x1, area->y1, width, height);
    tft.pushColors(reinterpret_cast<uint16_t *>(&colorP->full),
                   width * height,
                   true);
    tft.endWrite();

    lv_disp_flush_ready(disp);
}

static lv_obj_t *makeLabel(lv_obj_t *parent,
                           const char *text,
                           const lv_font_t *font,
                           uint32_t color) {
    lv_obj_t *label = lv_label_create(parent);
    lv_label_set_text(label, text);
    lv_obj_set_style_text_font(label, font, LV_PART_MAIN);
    lv_obj_set_style_text_color(label, lv_color_hex(color), LV_PART_MAIN);
    return label;
}

static void createCard(uint8_t channel, int x, int y) {
    lv_obj_t *card = lv_obj_create(lv_scr_act());
    lv_obj_remove_style_all(card);
    lv_obj_set_pos(card, x, y);
    lv_obj_set_size(card, 112, 50);
    lv_obj_clear_flag(card, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_set_style_bg_color(card, lv_color_hex(0x151A23), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(card, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_radius(card, 9, LV_PART_MAIN);
    lv_obj_set_style_border_width(card, 1, LV_PART_MAIN);
    lv_obj_set_style_border_color(card, lv_color_hex(0x252C38), LV_PART_MAIN);

    lv_obj_t *accent = lv_obj_create(card);
    lv_obj_remove_style_all(accent);
    lv_obj_set_pos(accent, 0, 8);
    lv_obj_set_size(accent, 3, 34);
    lv_obj_set_style_bg_color(accent, lv_color_hex(accentColors[channel]), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(accent, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_radius(accent, 3, LV_PART_MAIN);

    char channelText[8];
    snprintf(channelText, sizeof(channelText), "NTC %u", channel + 1);
    lv_obj_t *channelLabel = makeLabel(card, channelText, &lv_font_montserrat_12, 0x8D98AA);
    lv_obj_set_pos(channelLabel, 9, 4);

    char resistorText[12];
    snprintf(resistorText, sizeof(resistorText), "%.2fk", Config::FIXED_R_OHM[channel] / 1000.0f);
    lv_obj_t *rLabel = makeLabel(card, resistorText, &lv_font_montserrat_12, 0x566274);
    lv_obj_align(rLabel, LV_ALIGN_TOP_RIGHT, -6, 4);

    tempLabels[channel] = makeLabel(card, "--.-\xC2\xB0 C", &lv_font_montserrat_24, 0xF3F6FA);
    lv_obj_align(tempLabels[channel], LV_ALIGN_BOTTOM_MID, 0, -3);
}

static void createUi() {
    lv_obj_t *screen = lv_scr_act();
    lv_obj_set_style_bg_color(screen, lv_color_hex(0x0B0E14), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(screen, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_clear_flag(screen, LV_OBJ_FLAG_SCROLLABLE);

    lv_obj_t *title = makeLabel(screen, "THERMAL / 4CH", &lv_font_montserrat_12, 0xD9E0EA);
    lv_obj_set_pos(title, 7, 5);

    statusDot = lv_obj_create(screen);
    lv_obj_remove_style_all(statusDot);
    lv_obj_set_size(statusDot, 6, 6);
    lv_obj_set_style_radius(statusDot, LV_RADIUS_CIRCLE, LV_PART_MAIN);
    lv_obj_set_style_bg_color(statusDot, lv_color_hex(0x5B6472), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(statusDot, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_pos(statusDot, 155, 9);

    statusLabel = makeLabel(screen, "ADS1115 | 8 SPS", &lv_font_montserrat_12, 0x697487);
    lv_obj_align(statusLabel, LV_ALIGN_TOP_RIGHT, -6, 5);

    createCard(0, 6,   25);
    createCard(1, 122, 25);
    createCard(2, 6,   80);
    createCard(3, 122, 80);
}

static void setAdcUiState(bool online) {
    if (online) {
        lv_label_set_text(statusLabel, "ADS1115 | 8 SPS");
        lv_obj_set_style_text_color(statusLabel, lv_color_hex(0x697487), LV_PART_MAIN);
        lv_obj_set_style_bg_color(statusDot, lv_color_hex(0x35D0BA), LV_PART_MAIN);
    } else {
        lv_label_set_text(statusLabel, "ADS1115 OFFLINE");
        lv_obj_set_style_text_color(statusLabel, lv_color_hex(0xFF6B6B), LV_PART_MAIN);
        lv_obj_set_style_bg_color(statusDot, lv_color_hex(0xFF6B6B), LV_PART_MAIN);
    }
}

static void updateUi() {
    char text[24];

    for (uint8_t i = 0; i < 4; ++i) {
        switch (probes[i].state) {
            case ProbeState::Valid:
                snprintf(text, sizeof(text), "%.1f\xC2\xB0 C", probes[i].filteredTemperature);
                lv_obj_set_style_text_color(tempLabels[i], lv_color_hex(0xF3F6FA), LV_PART_MAIN);
                break;
            case ProbeState::Open:
                snprintf(text, sizeof(text), "OPEN");
                lv_obj_set_style_text_color(tempLabels[i], lv_color_hex(0xFFB547), LV_PART_MAIN);
                break;
            case ProbeState::Short:
                snprintf(text, sizeof(text), "SHORT");
                lv_obj_set_style_text_color(tempLabels[i], lv_color_hex(0xFF6B6B), LV_PART_MAIN);
                break;
            case ProbeState::AdcError:
                snprintf(text, sizeof(text), "ERROR");
                lv_obj_set_style_text_color(tempLabels[i], lv_color_hex(0xFF6B6B), LV_PART_MAIN);
                break;
            default:
                snprintf(text, sizeof(text), "--.-\xC2\xB0 C");
                lv_obj_set_style_text_color(tempLabels[i], lv_color_hex(0x6A7484), LV_PART_MAIN);
                break;
        }

        lv_label_set_text(tempLabels[i], text);
    }
}

// -----------------------------------------------------------------------------
// Non-blocking 4-channel acquisition state machine
// -----------------------------------------------------------------------------

static bool adsOnline = false;
static bool conversionRunning = false;
static uint8_t activeChannel = 0;
static uint32_t conversionStartedMs = 0;
static uint32_t lastAdsRetryMs = 0;

static void markAdsOffline() {
    adsOnline = false;
    conversionRunning = false;
    for (auto &p : probes) {
        p.state = ProbeState::AdcError;
    }
    setAdcUiState(false);
    updateUi();
}

static bool startChannel(uint8_t channel) {
    if (!ADS1115::startSingleEnded(channel)) {
        return false;
    }
    activeChannel = channel;
    conversionStartedMs = millis();
    conversionRunning = true;
    return true;
}

static void tryStartAds() {
    if (!ADS1115::probe()) {
        markAdsOffline();
        return;
    }

    adsOnline = true;
    setAdcUiState(true);
    if (!startChannel(0)) {
        markAdsOffline();
    }
}

static void serviceAds() {
    const uint32_t now = millis();

    if (!adsOnline) {
        if (now - lastAdsRetryMs >= 1000) {
            lastAdsRetryMs = now;
            tryStartAds();
        }
        return;
    }

    if (!conversionRunning) {
        if (!startChannel(activeChannel)) {
            markAdsOffline();
        }
        return;
    }

    // One 8-SPS conversion nominally takes 125 ms. Avoid needless I2C polling
    // until we are close to the end of the conversion.
    const uint32_t elapsed = now - conversionStartedMs;
    if (elapsed < 118) return;

    bool ready = false;
    if (!ADS1115::conversionReady(ready)) {
        markAdsOffline();
        return;
    }

    if (!ready) {
        if (elapsed > 180) {
            markAdsOffline();
        }
        return;
    }

    int16_t raw = 0;
    if (!ADS1115::readConversion(raw)) {
        markAdsOffline();
        return;
    }

    calculateProbe(activeChannel, raw);
    conversionRunning = false;

    if (activeChannel == 3) {
        // All four channels have now been refreshed. At 8 SPS this happens
        // approximately every 4 x 125 ms = 500 ms.
        updateUi();
        activeChannel = 0;
    } else {
        ++activeChannel;
    }

    if (!startChannel(activeChannel)) {
        markAdsOffline();
    }
}

// -----------------------------------------------------------------------------
// Arduino setup/loop
// -----------------------------------------------------------------------------

void setup() {
    Serial.begin(115200);
    delay(50);

    Wire.begin(Config::I2C_SDA, Config::I2C_SCL);
    Wire.setClock(Config::I2C_CLOCK_HZ);

    pinMode(TFT_BL, OUTPUT);
    digitalWrite(TFT_BL, LOW);

    tft.init();
    tft.setRotation(1); // 240 x 135 landscape
    tft.fillScreen(TFT_BLACK);
    digitalWrite(TFT_BL, TFT_BACKLIGHT_ON);

    lv_init();
    lv_disp_draw_buf_init(&drawBuffer, drawPixels, nullptr,
                          sizeof(drawPixels) / sizeof(drawPixels[0]));

    static lv_disp_drv_t displayDriver;
    lv_disp_drv_init(&displayDriver);
    displayDriver.hor_res = Config::SCREEN_W;
    displayDriver.ver_res = Config::SCREEN_H;
    displayDriver.flush_cb = displayFlush;
    displayDriver.draw_buf = &drawBuffer;
    lv_disp_drv_register(&displayDriver);

    createUi();
    updateUi();

    tryStartAds();
}

void loop() {
    static uint32_t lastLvTick = millis();
    const uint32_t now = millis();
    const uint32_t elapsed = now - lastLvTick;
    if (elapsed > 0) {
        lv_tick_inc(elapsed);
        lastLvTick = now;
    }

    serviceAds();
    lv_timer_handler();

    delay(2);
}
