#pragma once

#include <Arduino.h>

namespace Config {

// I2C
constexpr int I2C_SDA = 21;
constexpr int I2C_SCL = 22;
constexpr uint32_t I2C_CLOCK_HZ = 400000;

// ADS1115: ADDR tied to VCC -> 0x49.
constexpr uint8_t ADS1115_ADDRESS = 0x49;

// Divider supply. Measure the actual voltage at the ADS1115 VDD pin with a DMM
// and put that value here for best absolute temperature accuracy.
constexpr float DIVIDER_VCC = 3.300f;

// NTC: 10 kOhm at 25 C, beta = 3435 K.
constexpr float NTC_R25_OHM = 10000.0f;
constexpr float NTC_BETA_K = 3435.0f;
constexpr float NTC_T0_K = 25.0f + 273.15f;

// Exact measured fixed resistors, fixed resistor to VCC, NTC to GND.
constexpr float FIXED_R_OHM[4] = {
    10000.0f,
    9820.0f,
    9870.0f,
    9860.0f
};

// Light software smoothing after the ADS1115's internal digital filtering.
// 1.0 = no extra smoothing. 0.35 is responsive but visually very stable.
constexpr float EMA_ALPHA = 0.35f;

// T-Display geometry after tft.setRotation(1).
constexpr int SCREEN_W = 240;
constexpr int SCREEN_H = 135;

} // namespace Config
