# T-Display 4-channel NTC monitor

PlatformIO project for the classic LilyGO/TTGO T-Display (ESP32, ST7789V 240x135) with one ADS1115 and four 10 kOhm B3435 NTC probes.

## Wiring

### ADS1115
- VDD -> ESP32 3.3 V
- GND -> GND
- SDA -> GPIO21
- SCL -> GPIO22
- ADDR -> VDD, so I2C address = 0x49

Do not power a typical ADS1115 breakout from 5 V if its I2C pull-ups are tied to VDD; that can put 5 V on SDA/SCL. This project assumes 3.3 V ADS1115 power and 3.3 V divider power.

### NTC dividers
Each channel is:

3.3 V -> fixed resistor -> ADS1115 AINx -> 10 kOhm B3435 NTC -> GND

Fixed resistors used by the firmware:
- A0: 10.00 kOhm
- A1: 9.82 kOhm
- A2: 9.87 kOhm
- A3: 9.86 kOhm

## ADC configuration

The ADS1115 is configured directly through its registers:
- single-ended AIN0..AIN3
- PGA: +/-4.096 V
- single-shot mode
- 8 SPS data rate
- comparator disabled

The 8-SPS mode gives the highest internal oversampling ratio / strongest internal digital filtering. At four sequential channels, one complete scan takes about 4 x 125 ms = 500 ms.

A light EMA is applied after the hardware-filtered readings. Set `EMA_ALPHA` in `include/config.h` to `1.0f` if you want no additional software smoothing.

## Calibration

For the best absolute temperature accuracy, measure the voltage at the ADS1115 VDD pin and replace:

`constexpr float DIVIDER_VCC = 3.300f;`

in `include/config.h` with the measured value.

The temperature calculation uses:
- R25 = 10,000 Ohm
- Beta = 3435 K
- T0 = 25 C

## Build

Open the directory as a PlatformIO project and upload the `t-display` environment.
